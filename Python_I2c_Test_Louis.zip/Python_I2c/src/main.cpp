#include <Arduino.h>
#include <Wire.h>

void setup() {
    Wire.begin(7, 6);  // SDA on GPIO 21, SCL on GPIO 22
    //Wire.beginTransmission(8);  // Replace 8 with the Raspberry Pi's I2C address if it's the master
    Wire.beginTransmission(0x0d);
}

void loop() {
    // Send data to Raspberry Pi
    Wire.write("Hello Pi");
    Wire.endTransmission();
    delay(1);
}
