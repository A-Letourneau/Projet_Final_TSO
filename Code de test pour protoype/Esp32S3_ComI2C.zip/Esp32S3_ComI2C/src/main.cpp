#include <Wire.h>
#include <stdio.h>
#include <stdlib.h>
#include <Arduino.h>

const int I2C_SLAVE_ADDRESS = 0x08;  // Match with the address in Pi code
// Define the analog pin (GPIO1 is ADC on ESP32-C3)
const int analogPin = 0;  // GPIO0
const int analogPin1 = 1;  // GPIO1 -> ADC1 channel
const int analogPin2 = 2; // GPIO2 -> ADC2 channel
const int analogPin3 = 3; // GPIO3 -> ADC3 channel

#define PotValueMax  4095
#define PotValueMin  0
#define PotScaleMax  255
#define PotScaleMin  0


// Function declarations
void receiveEvent(int bytes);
void requestEvent();
int getData(int SelectedPin);
bool DataButton(int ButtonValue);
int analogScale(int value, int minValue, int maxValue, int minScale, int maxScale);


//ini data 
int PotValue1 = 0;
int PotValue2 =0;
int buttonValue1 =0;
int buttonValue2 =0;


void setup() {
  Wire.begin(I2C_SLAVE_ADDRESS);     // Initialize I2C with address
  Wire.onReceive(receiveEvent);      // Register receive event
  Wire.onRequest(requestEvent);      // Register request event
  Serial.begin(9600);
  Serial.println("ESP32 I2C Slave initialized");

  // Set ADC resolution to 12 bits (4096 levels)
  analogReadResolution(12);


}

void loop() {
  // Read analog value from selected pin
  PotValue1 = getData(analogPin);
  PotValue2 = getData(analogPin1);
  buttonValue1 = getData(analogPin2);
  buttonValue2 = getData(analogPin3);

  // Check if button is pressed
  DataButton(buttonValue2);
  DataButton(buttonValue1);
  // Scale the analog values to 0-255
  PotValue1 = analogScale(PotValue1, PotValueMin, PotValueMax, PotScaleMin, PotScaleMax);
  PotValue2 = analogScale(PotValue2, PotValueMin, PotValueMax, PotScaleMin, PotScaleMax);

  // Print the values to the Serial Monitor
  
  Serial.print("\n\n\n\n\n\n\n\n\n\n");
  Serial.print("Analog Value 1: ");
  Serial.println(PotValue1);
  Serial.print("Analog Value 2: ");
  Serial.println(PotValue2);
  Serial.print("Button Value 1: ");
  Serial.println(DataButton(buttonValue1));
  Serial.print("Button Value 2: ");
  Serial.println(DataButton(buttonValue2));
  Serial.print("\n");

  requestEvent();

  delay(2000);  // Keep the loop running

  //delay(100);  // Keep the loop running
}

// Function to handle data received from master
void receiveEvent(int bytes) {
  while (Wire.available()) {
    char c = Wire.read();
    Serial.print("Received: ");
    Serial.println(c);
  }
}

// Function to handle data request from master
/*void requestEvent() {
  Wire.write(PotValue1|PotValue2|buttonValue1|buttonValue2);  // Send back an example byte
  Serial.println(PotValue1|PotValue2|buttonValue1|buttonValue2);
  Serial.println("Data sent to Raspberry Pi");
}*/
// Function to handle data request from master
void requestEvent() {
  Wire.write(PotValue1);  // Send PotValue1
  Wire.write(PotValue2);  // Send PotValue2
  Wire.write(buttonValue1);  // Send buttonValue1
  Wire.write(buttonValue2);  // Send buttonValue2
  
  Serial.print("Data sent to Raspberry Pi: ");
  Serial.print(PotValue1);
  Serial.print(", ");
  Serial.print(PotValue2);
  Serial.print(", ");
  Serial.print(DataButton(buttonValue1));
  Serial.print(", ");
  Serial.println(DataButton(buttonValue2));
}

int getData(int SelectedPin)
{
  // Print the value to the Serial Monitor
  int PotValue1 = analogRead(SelectedPin);

  

  //Serial.print("Analog Value: ");
  //Serial.println(PotValue1);
  //requestEvent(); 


  // value = analogRead(analogPin);
  return PotValue1;
}

bool DataButton(int buttonValue)
{
  bool buttonTruth = false;
  if (buttonValue <= 2000) 
  {
    buttonTruth = false;
  }
  else if (buttonValue > 2000)
  {
    buttonTruth = true;
  }
  // value = analogRead(analogPin);
  return buttonTruth ;
}


int analogScale(int value, int minValue, int maxValue, int minScale, int maxScale)
{
  // Correct scale factor calculation with floating-point division
  float scaleFactor = (float)(maxScale - minScale) / (maxValue - minValue);
  
  // Correctly calculate the scaled value
  int newValue = minScale + (value - minValue) * scaleFactor;
  return newValue;
}
/*#include <Arduino.h>

// Define the analog pin (GPIO1 is ADC on ESP32-C3)
const int analogPin = 1;  // GPIO1 -> ADC1 channel

void setup() {
  // Start the serial communication at 115200 baud rate
  Serial.begin(9600, SERIAL_8O1);
  
  // Wait for the serial monitor to open
  while (!Serial) {
    delay(10);
  }
}

void loop() 
{
  // Read the value from the analog pin (range 0 to 4095)
  int analogValue = analogRead(analogPin);
  
  // Print the value to the Serial Monitor
  int analogValue = analogRead(analogPin);
  Serial.print("Analog Value: ");
  Serial.println(analogValue);
  

  
  // Small delay before the next read
  delay(500);
  
}


*/
// Define the analog pin (can be any pin supporting ADC on ESP32)
//const int analogPin = 0;  // GPIO34 is an ADC1 pin


/*#include <HardwareSerial.h>

HardwareSerial MySerial(1); // define a Serial for UART1
const int MySerialRX = 16;
const int MySerialTX = 17;

void setup() 
{
	// initialize the Serial to the pins
    MySerial.begin(11500, SERIAL_8N1, MySerialRX, MySerialTX);
}

void loop() 
{
	// here we could use our MySerial normally
    while (MySerial.available() > 0) {
        uint8_t byteFromSerial = MySerial.read();

        printf("Serial");
        
        //and whatever else


    }
    
   
    //MySerial.write(...);

      // Small delay before the next read
  //delay(500);
}*/